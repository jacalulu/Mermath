"""The remaining Mermath scenes in the locked look, each drawn as named layers (same recipe as the Tide Pool and home scenes in frame.py)."""
import math, os
from scenes import W, H, kelp, hill, coral, mound, rock, seastar, grass, school, hexmix, strand
from chars import star
from frame import LS, boulder

SURFACE = ('<path d="M-20 -20 L820 -20 L820 26 C740 44 690 14 610 30 C520 48 470 16 380 32 C300 46 240 18 160 34 C100 46 40 26 -20 38 Z" fill="#f4fff9" opacity=".85" filter="url(#b3)"/>'
           '<path d="M-20 46 C60 32 110 60 190 48 C270 36 330 64 410 52 C500 38 560 66 640 52 C710 40 770 60 820 48" fill="none" stroke="#ffffff" stroke-width="5" opacity=".55" filter="url(#b1)"/>')
RAYS = [(-30, 5), (-18, 7), (-6, 4), (6, 8), (18, 5), (30, 6), (42, 4)]
SAND = [(0, '#f7e6ba', 1), (1, '#d6b27c', 1)]; SAND2 = [(0, '#fbeecd', 1), (1, '#c9a06c', 1)]

def open_water(s, cols=('#dcfcef', '#93e7d7', '#3db5be', '#1b86a1', '#12617f')):
    """The locked water: pale surface, teal depth, light from the upper left."""
    s.layer('bg'); s.water(list(cols), [0, .1, .38, .72, 1]); s.bloom(300, -40, 540, '#ffffff', .9, 330); s.add(SURFACE)

def sand(s, r, y, amp, fill, caustic=True):
    d, top = hill(r, y, amp); s.add(f'<path d="{d}" fill="{s.lin(fill)}"/>')
    if caustic: s.add(f'<g clip-path="{s.clip(d)}"><rect width="{W}" height="{H}" filter="url(#caustic)" opacity=".55" style="mix-blend-mode:screen"/></g>')

def shell_on_sand(x, y):
    return f'<path d="M{x-13} {y} A13 13 0 0 1 {x+13} {y} Z" fill="#fff4dc" stroke="#e8c79a" stroke-width="1.5"/><path d="M{x} {y} L{x-8} {y-9} M{x} {y} L{x} {y-13} M{x} {y} L{x+8} {y-9}" stroke="#e8c79a" stroke-width="1.5"/>'

def scene_coral_layers():
    """Coral Reef dive: the crab's rock on the left, open water behind the answers, bright coral in the bottom corners."""
    s = LS(419, 300, -230, 1000); r = s.r
    open_water(s)
    reef = coral(r, 330, 486, '#4fb3bb', '#9be5df', 150, 4, 13, -94) + coral(r, 470, 492, '#4fb3bb', '#9be5df', 120, 4, 11, -86) + coral(r, 600, 484, '#4fb3bb', '#9be5df', 160, 4, 13, -92)
    s.add(f'<g filter="url(#b3)" opacity=".5">{reef}</g>')
    far = ''.join(kelp(r, x + r.uniform(-12, 12), 6, '#6fd0cd', (30, 56), (6, 10), (22, 38)) for x in (250, 396, 540, 684))
    s.layer('kelp_far').add(f'<g filter="url(#b3)" opacity=".6">{far}</g>')
    d, top = hill(r, 462, 14); s.layer('bg').add(f'<path d="{d}" fill="#52bcc0" opacity=".7" filter="url(#b3)"/>')
    s.rays(RAYS, 1000, .5)
    s.layer('fan_left').add(f'<g filter="url(#paintS)">{coral(r, 44, 484, "#6a43b8", "#d9c2ff", 230, 5, 10, -86)}</g>')
    s.layer('fan_right').add(f'<g filter="url(#paintS)">{coral(r, 782, 520, "#b03070", "#ffb3d6", 118, 4, 9, -93)}</g>')
    s.layer('fg'); sand(s, r, 470, 8, SAND)
    s.add(boulder(s, 712, 548, 240, 96) + boulder(s, 590, 566, 110, 46, moss=False))
    s.add(coral(r, 738, 470, '#5a3aa8', '#d2b4ff', 150, 4, 17, -94) + coral(r, 668, 500, '#b23a2a', '#ffb347', 110, 4, 14, -80))
    s.add(boulder(s, 140, 486, 310, 100) + boulder(s, 300, 544, 120, 52, moss=False))
    s.add('<ellipse cx="140" cy="402" rx="96" ry="12" fill="#0d3a50" opacity=".5" filter="url(#b6)"/>')
    sand(s, r, 566, 6, SAND2, caustic=False)
    s.add(coral(r, 40, 600, '#b23a2a', '#ffb347', 160, 4, 18, -84) + coral(r, 118, 606, '#b03070', '#ff9ecb', 112, 4, 14, -98) + coral(r, 178, 604, '#5a3aa8', '#c9a8ff', 80, 3, 12, -78))
    s.add(coral(r, 768, 604, '#b03070', '#ff9ecb', 128, 4, 15, -96) + coral(r, 704, 606, '#2f9c86', '#9df0d0', 84, 3, 12, -84))
    s.add(mound(s, 246, 598, 44, 36, '#35c6a8', '#12788c') + mound(s, 620, 598, 40, 32, '#ffb347', '#c9562b'))
    s.add(seastar(450, 588, 9, '#ffd27a', -70) + shell_on_sand(350, 590) + shell_on_sand(540, 592))
    s.layer('grass').add(grass(r, 318, 596, 6, 24, 54, '#1f9c7c', '#3fc79a') + grass(r, 520, 596, 6, 22, 50, '#1f9c7c', '#3fc79a'))
    s.layer('bg'); s.finish(mott=.26, streak=.14, vig=0, grain=0)
    return {n: s.svg_layer(n) for n in ('bg', 'kelp_far', 'fan_left', 'fan_right', 'fg', 'grass')}

def lamp(s, x, y, R, face=False):
    """The starfish lamp. Its face is drawn separately so it stays crisp."""
    if face:
        k = R / 58
        return (f'<circle cx="{x-10*k:.1f}" cy="{y-2*k:.1f}" r="{4*k:.1f}" fill="#7a3d12"/><circle cx="{x+10*k:.1f}" cy="{y-2*k:.1f}" r="{4*k:.1f}" fill="#7a3d12"/>'
                f'<path d="M{x-8*k:.1f} {y+8*k:.1f} Q{x:.1f} {y+16*k:.1f} {x+8*k:.1f} {y+8*k:.1f}" fill="none" stroke="#7a3d12" stroke-width="{3*k:.1f}" stroke-linecap="round"/>'
                f'<circle cx="{x-8.6*k:.1f}" cy="{y-3.4*k:.1f}" r="{1.4*k:.1f}" fill="#fff"/><circle cx="{x+11.4*k:.1f}" cy="{y-3.4*k:.1f}" r="{1.4*k:.1f}" fill="#fff"/>')
    sg = s.rad([(0, '#fffbe0', 1), (.45, '#ffd45e', 1), (1, '#ff9a3d', 1)])
    out = f'<polygon points="{star(x, y, R, R*.47, -90)}" fill="{sg}" stroke="#ffe9a8" stroke-width="{R*.16:.1f}" stroke-linejoin="round"/>'
    for i in range(5):
        a = math.radians(-90 + i * 72)
        out += f'<circle cx="{x+R*.52*math.cos(a):.1f}" cy="{y+R*.52*math.sin(a):.1f}" r="{R*.062:.1f}" fill="#fff8d6"/><circle cx="{x+R*.76*math.cos(a):.1f}" cy="{y+R*.76*math.sin(a):.1f}" r="{R*.045:.1f}" fill="#fff8d6"/>'
    return out

def scene_chest_layers():
    """Treasure chest: a kelp clearing with the open chest in the middle and warm light pouring out of it."""
    s = LS(523, 300, -230, 1000); r = s.r
    open_water(s, ('#dcfcef', '#8fe3d6', '#35aab8', '#167c9b', '#0e5576'))
    far = ''.join(kelp(r, x + r.uniform(-12, 12), 6, '#6fd0cd', (30, 56), (6, 10), (22, 38)) for x in (170, 262, 548, 640, 716))
    s.layer('kelp_far').add(f'<g filter="url(#b3)" opacity=".6">{far}</g>')
    d, top = hill(r, 474, 14); s.layer('bg').add(f'<path d="{d}" fill="#4ab4bd" opacity=".7" filter="url(#b3)"/>')
    s.rays(RAYS, 1000, .5)
    s.bloom(400, 340, 300, '#ffe9a8', .8)
    fan = s.lin([(0, '#fff3c4', .9), (.6, '#ffe08a', .3), (1, '#ffe08a', 0)], x1=0, y1=1, x2=0, y2=0)
    s.add(f'<g filter="url(#b12)" style="mix-blend-mode:screen"><polygon points="320,372 480,372 620,60 180,60" fill="{fan}" opacity=".6"/><polygon points="370,372 430,372 468,60 332,60" fill="{fan}" opacity=".55"/></g>')
    mid = kelp(r, 104, 12, '#1f8f95', (46, 86), (10, 16), (28, 46), lean=16) + kelp(r, 700, 11, '#1f8f95', (40, 72), (9, 15), (26, 44), lean=-14)
    s.layer('kelp_mid').add(f'<g filter="url(#paintS)">{mid}</g>')
    s.layer('fg'); sand(s, r, 490, 8, SAND)
    s.add('<ellipse cx="400" cy="496" rx="230" ry="30" fill="#fff3c4" opacity=".6" filter="url(#b12)"/>')
    s.add(boulder(s, 64, 572, 200, 74) + boulder(s, 742, 574, 220, 84))
    sand(s, r, 582, 5, SAND2, caustic=False)
    s.add('<ellipse cx="400" cy="482" rx="132" ry="14" fill="#7a5a2a" opacity=".5" filter="url(#b6)"/>')
    s.add(''.join(f'<ellipse cx="{x}" cy="{y}" rx="12" ry="5" fill="#ffd866" stroke="#e09a1f" stroke-width="1.5"/>' for x, y in ((262, 498), (284, 506), (530, 500), (552, 508), (246, 510))))
    s.add(seastar(596, 590, 9, '#ffd27a', -70) + shell_on_sand(212, 592))
    # the chest: lid (behind) and box (in front) are separate pieces
    lid = 'M298 374 C292 300 338 258 400 258 C462 258 508 300 502 374 Z'
    s.layer('chest_lid').add(f'<path d="{lid}" fill="{s.lin([(0, "#3a1414", 1), (1, "#7a2f22", 1)])}"/>')
    s.add(f'<g clip-path="{s.clip(lid)}"><ellipse cx="400" cy="384" rx="120" ry="80" fill="#ffd27a" opacity=".75" filter="url(#b12)"/><path d="M330 372 L352 268 M400 372 L400 258 M470 372 L448 268" stroke="#2a0c0c" stroke-width="2" opacity=".5"/></g>')
    s.add(f'<path d="{lid}" fill="none" stroke="#6a3c1a" stroke-width="14" stroke-linejoin="round"/><path d="{lid}" fill="none" stroke="#ffd27a" stroke-width="4" stroke-linejoin="round"/>')
    s.add('<path d="M350 372 C348 318 360 284 372 264" fill="none" stroke="#e0aa42" stroke-width="9"/><path d="M450 372 C452 318 440 284 428 264" fill="none" stroke="#e0aa42" stroke-width="9"/>')
    s.layer('chest_box').add('<ellipse cx="400" cy="366" rx="100" ry="30" fill="#fff3c4"/><ellipse cx="400" cy="378" rx="96" ry="20" fill="#ffc94d"/>')
    coins = ''
    for i in range(15):
        x = 316 + i * 12 + r.uniform(-3, 3); y = 368 - 10 * math.sin(math.pi * i / 14) + r.uniform(-3, 3)
        coins += f'<ellipse cx="{x:.0f}" cy="{y:.0f}" rx="11" ry="9" fill="#ffd866" stroke="#e09a1f" stroke-width="1.5"/><ellipse cx="{x-2:.0f}" cy="{y-2:.0f}" rx="5" ry="3.5" fill="#fff3c4" opacity=".8"/>'
    s.add(coins)
    pearl = s.rad([(0, '#ffffff', 1), (.6, '#fff1e2', 1), (1, '#e3c4a8', 1)], cx=.35, cy=.3, rr=.8)
    s.add(''.join(f'<circle cx="{x}" cy="{y}" r="{rr}" fill="{pearl}"/>' for x, y, rr in ((346, 362, 8), (378, 352, 9), (414, 354, 8), (446, 362, 9), (400, 344, 7))))
    box = 'M296 380 L504 380 L494 474 L306 474 Z'
    s.add(f'<path d="{box}" fill="{s.lin([(0, "#9a5a28", 1), (1, "#4a2410", 1)])}"/>')
    s.add(f'<g clip-path="{s.clip(box)}"><path d="M290 412 L510 412 M290 444 L510 444" stroke="#2f1508" stroke-width="2.5" opacity=".6"/><rect x="290" y="380" width="70" height="100" fill="#1a0a04" opacity=".45" filter="url(#b12)"/><rect x="470" y="380" width="40" height="100" fill="#ffcf7a" opacity=".25" filter="url(#b6)"/></g>')
    gold = s.lin([(0, '#fff0b0', 1), (.5, '#ffcf5a', 1), (1, '#c9882a', 1)])
    s.add(f'<path d="M288 370 L512 370 L508 392 L292 392 Z" fill="{gold}"/><path d="M304 458 L496 458 L494 476 L306 476 Z" fill="{gold}"/><path d="M332 392 L348 392 L350 458 L336 458 Z" fill="{gold}"/><path d="M452 392 L468 392 L464 458 L450 458 Z" fill="{gold}"/>')
    s.add(f'<rect x="383" y="388" width="34" height="42" rx="9" fill="{gold}" stroke="#a86a14" stroke-width="2"/><circle cx="400" cy="404" r="5.5" fill="#3a1a0a"/><path d="M396 406 L404 406 L402 420 L398 420 Z" fill="#3a1a0a"/>')
    s.add(''.join(f'<circle cx="{x}" cy="{y}" r="3.5" fill="#fff3c4"/>' for x, y in ((300, 381), (500, 381), (340, 381), (460, 381), (312, 467), (488, 467))))
    s.add(''.join(f'<circle cx="{x}" cy="{y}" r="5" fill="{pearl}"/>' for x, y in ((430, 376), (438, 388), (442, 400), (443, 412), (441, 424))))
    s.layer('lamp').add(lamp(s, 400, 178, 58)); s.layer('lamp_face').add(lamp(s, 400, 178, 58, face=True))
    s.layer('grass').add(grass(r, 160, 592, 7, 28, 60, '#1f9c7c', '#3fc79a') + grass(r, 640, 592, 7, 26, 58, '#1f9c7c', '#3fc79a'))
    s.layer('bg'); s.finish(mott=.26, streak=.14, vig=0, grain=0)
    return {n: s.svg_layer(n) for n in ('bg', 'kelp_far', 'kelp_mid', 'fg', 'chest_lid', 'chest_box', 'lamp', 'lamp_face', 'grass')}

WALL, WALL_D, WALL_L = '#0f4a5c', '#0a3444', '#2c8a98'

def scene_grotto_layers():
    """My grotto: inside a sea cave, looking out at the lit water. Walls frame both sides; the floor is pale sand."""
    s = LS(631, 400, -260, 1000); r = s.r
    s.layer('bg').add(f'<rect width="{W}" height="{H}" fill="{s.rad([(0, "#dcfcef", 1), (.3, "#8fe3d6", 1), (.62, "#35aab8", 1), (1, "#167c9b", 1)], cx=.5, cy=.2, rr=.9)}"/>')
    back = '<path d="M150 620 C160 420 220 330 300 300 C330 380 330 500 320 620 Z" fill="#2f9fb0"/><path d="M500 620 C490 480 500 370 540 310 C610 340 650 450 660 620 Z" fill="#2f9fb0"/><path d="M330 620 C340 520 370 470 400 460 C440 470 470 520 480 620 Z" fill="#3aabb8"/>'
    s.add(f'<g filter="url(#b3)" opacity=".7">{back}</g>')
    s.bloom(400, -10, 320, '#ffffff', .95); s.rays([(-13, 7), (-4, 5), (5, 8), (14, 5)], 1000, .6)
    s.layer('floor'); sand(s, r, 520, 8, SAND)
    s.add('<ellipse cx="400" cy="536" rx="220" ry="46" fill="#fff6d8" opacity=".6" filter="url(#b12)"/>')
    lw = 'M-20 -20 L262 -20 C210 40 160 84 138 164 C118 244 146 300 108 384 C84 446 116 520 60 620 L-20 620 Z'
    rw = 'M820 -20 L548 -20 C600 50 656 74 674 152 C694 242 662 312 702 392 C726 452 698 530 746 620 L820 620 Z'
    s.layer('walls').add(f'<g filter="url(#paint)"><path d="{lw}" fill="{s.lin([(0, WALL_L, 1), (.35, WALL, 1), (1, WALL_D, 1)], x1=1, y1=0, x2=0, y2=0)}"/><path d="{rw}" fill="{s.lin([(0, WALL_L, 1), (.35, WALL, 1), (1, WALL_D, 1)], x1=0, y1=0, x2=1, y2=0)}"/>'
                          f'<path d="{lw}" transform="translate(-40 0)" fill="{WALL_D}"/><path d="{rw}" transform="translate(40 0)" fill="{WALL_D}"/>'
                          f'<path d="M262 -20 L300 70 L330 -20 Z M470 -20 L498 84 L548 -20 Z M190 -20 L214 54 L240 -20 Z M580 -20 L598 60 L620 -20 Z" fill="{WALL}"/></g>')
    s.add(f'<path d="M262 -20 C210 40 160 84 138 164 C118 244 146 300 108 384 C84 446 116 520 60 620" fill="none" stroke="#bff7e6" stroke-width="3" opacity=".55" filter="url(#b1)"/><path d="M548 -20 C600 50 656 74 674 152 C694 242 662 312 702 392 C726 452 698 530 746 620" fill="none" stroke="#bff7e6" stroke-width="3" opacity=".55" filter="url(#b1)"/>')
    def crystal(x, y, h, col, rot):
        return f'<g transform="translate({x} {y}) rotate({rot})"><path d="M0 0 L{-h*.2:.0f} {-h*.7:.0f} L0 {-h} L{h*.2:.0f} {-h*.7:.0f} Z" fill="{col}"/><path d="M0 0 L0 {-h} L{h*.2:.0f} {-h*.7:.0f} Z" fill="#ffffff" opacity=".45"/></g>'
    s.add(crystal(96, 500, 60, '#8ff0ff', -14) + crystal(118, 508, 44, '#b79cff', 10) + crystal(76, 510, 36, '#8ff0ff', -32) + crystal(716, 500, 54, '#b79cff', 16) + crystal(738, 512, 38, '#8ff0ff', 34))
    s.add(boulder(s, 40, 590, 150, 50, moss=False) + boulder(s, 770, 592, 150, 52, moss=False))
    cur = ''.join(strand(r, x, 60 + r.uniform(0, 30), ln, '#27b592', '#5fe0b6') for x, ln in ((612, 300), (640, 350), (668, 320), (694, 270)))
    s.layer('curtain').add(cur)
    cx, cy = 520, 492; n = 8
    ed = f'M{cx-112} {cy} ' + ''.join(f'Q{cx+128*math.cos(math.pi+math.pi*(i+.5)/n):.0f} {cy+118*math.sin(math.pi+math.pi*(i+.5)/n):.0f} {cx+112*math.cos(math.pi+math.pi*(i+1)/n):.0f} {cy+100*math.sin(math.pi+math.pi*(i+1)/n):.0f} ' for i in range(n)) + 'Z'
    s.layer('floor').add(f'<ellipse cx="{cx}" cy="{cy+44}" rx="130" ry="14" fill="#7a5a2a" opacity=".45" filter="url(#b6)"/>')
    s.layer('bed').add(f'<path d="{ed}" fill="{s.lin([(0, "#fff0fa", 1), (.6, "#f7b9e4", 1), (1, "#d98ac9", 1)])}" stroke="#c77ab8" stroke-width="3" stroke-linejoin="round"/>')
    s.add(''.join(f'<path d="M{cx} {cy} L{cx+106*math.cos(math.pi+math.pi*i/n):.0f} {cy+96*math.sin(math.pi+math.pi*i/n):.0f}" stroke="#d98ac9" stroke-width="3" opacity=".6"/>' for i in range(1, n)))
    s.add(f'<ellipse cx="{cx}" cy="{cy}" rx="112" ry="20" fill="#fff5fb"/><ellipse cx="{cx-10}" cy="{cy-5}" rx="88" ry="17" fill="{s.lin([(0, "#e3d4ff", 1), (1, "#b79cff", 1)])}"/><ellipse cx="{cx-30}" cy="{cy-10}" rx="40" ry="6" fill="#ffffff" opacity=".5"/>')
    s.add(f'<path d="M{cx-114} {cy} C{cx-110} {cy+66} {cx+110} {cy+66} {cx+114} {cy} C{cx+80} {cy+20} {cx-80} {cy+20} {cx-114} {cy} Z" fill="{s.lin([(0, "#f09fd8", 1), (1, "#9a4f9f", 1)])}"/>')
    s.add(''.join(f'<path d="M{cx+k*26} {cy+16} Q{cx+k*30} {cy+34} {cx+k*24} {cy+48}" fill="none" stroke="#7a3a82" stroke-width="2.5" opacity=".5"/>' for k in (-3, -2, -1, 0, 1, 2, 3)))
    s.add(f'<circle cx="{cx+66}" cy="{cy-12}" r="15" fill="{s.rad([(0, "#ffffff", 1), (.6, "#fff1e2", 1), (1, "#e3c4a8", 1)], cx=.35, cy=.3, rr=.8)}"/>')
    lights = ''
    for (x0, y0), (x1, y1), sag in (((150, 96), (400, 60), 46), ((400, 60), (650, 96), 46)):
        lights += f'<path d="M{x0} {y0} Q{(x0+x1)/2} {(y0+y1)/2+sag*2} {x1} {y1}" fill="none" stroke="#0a3444" stroke-width="2.5"/>'
        for i in range(1, 8):
            t = i / 8; x = (1-t)**2*x0 + 2*(1-t)*t*(x0+x1)/2 + t*t*x1; y = (1-t)**2*y0 + 2*(1-t)*t*((y0+y1)/2+sag*2) + t*t*y1
            lights += f'<circle cx="{x:.0f}" cy="{y+6:.0f}" r="15" fill="url(#spark)" opacity=".95"/><circle cx="{x:.0f}" cy="{y+6:.0f}" r="5" fill="#fff6d8"/>'
    s.layer('lights').add(lights)
    s.layer('lamp').add(lamp(s, 400, 178, 44)); s.layer('lamp_face').add(lamp(s, 400, 178, 44, face=True))
    s.layer('bg'); s.finish(mott=.26, streak=.14, vig=0, grain=0)
    return {n: s.svg_layer(n) for n in ('bg', 'floor', 'walls', 'curtain', 'bed', 'lights', 'lamp', 'lamp_face')}

def scene_map_layers():
    """Reef map: one seabed stepping down from the bright shallows on the left to the dark deep on the right, with a place on each step."""
    s = LS(747, 300, -230, 1000); r = s.r
    open_water(s, ('#dcfcef', '#8fe3d6', '#35aab8', '#167c9b', '#0e5576'))
    s.add(f'<rect width="{W}" height="{H}" fill="{s.lin([(.3, "#0b2e57", 0), (1, "#0b2e57", .6)], x1=0, y1=.2, x2=1, y2=.8)}"/>')
    far = ''.join(kelp(r, x + r.uniform(-12, 12), 6, '#6fd0cd', (30, 56), (6, 10), (22, 38)) for x in (250, 330, 540, 612))
    s.layer('kelp_far').add(f'<g filter="url(#b3)" opacity=".55">{far}</g>')
    s.layer('bg').add('<path d="M-20 300 C120 280 260 300 400 350 C540 400 680 420 820 436 L820 620 L-20 620 Z" fill="#4ab4bd" opacity=".55" filter="url(#b3)"/>')
    s.rays(RAYS, 1000, .5)
    mid = kelp(r, 20, 12, '#1f8f95', (46, 86), (10, 16), (28, 46), lean=18) + kelp(r, 786, 11, '#14707c', (40, 72), (9, 15), (26, 44), lean=-12)
    s.layer('kelp_mid').add(f'<g filter="url(#paintS)">{mid}</g>')
    s.layer('floor')
    fl = 'M-20 326 C60 314 200 318 270 334 C300 342 304 372 322 388 C360 402 500 396 548 410 C580 420 580 448 600 462 C640 476 760 468 820 474 L820 620 L-20 620 Z'
    s.add(f'<path d="{fl}" fill="{s.lin(SAND)}"/>')
    s.add(f'<g clip-path="{s.clip(fl)}"><rect width="{W}" height="{H}" filter="url(#caustic)" opacity=".5" style="mix-blend-mode:screen"/>'
          f'<path d="M270 334 C300 342 304 372 322 388 L322 620 L262 620 Z" fill="#b98f5c" opacity=".55" filter="url(#b6)"/><path d="M548 410 C580 420 580 448 600 462 L600 620 L540 620 Z" fill="#8a744f" opacity=".6" filter="url(#b6)"/>'
          f'<rect width="{W}" height="{H}" fill="{s.lin([(.34, "#0b2e57", 0), (.7, "#0b2e57", .42), (1, "#0b2e57", .62)], x1=0, y1=0, x2=1, y2=0)}"/></g>')
    # 1. Tide Pool: sunlit sand, mossy rocks around a pale pool
    s.add(boulder(s, 58, 356, 124, 66) + boulder(s, 232, 360, 100, 48, moss=False))
    s.add('<ellipse cx="146" cy="356" rx="72" ry="17" fill="#e9fffa"/><ellipse cx="146" cy="358" rx="63" ry="12.5" fill="#9ee9de"/><ellipse cx="128" cy="354" rx="26" ry="4.5" fill="#ffffff" opacity=".7"/>')
    s.add(seastar(214, 374, 10, '#ff7eb6', -80) + grass(r, 100, 378, 4, 14, 30, '#1f9c7c', '#3fc79a') + shell_on_sand(176, 384))
    # 2. Coral Reef: bright coral on the middle step
    s.add(coral(r, 372, 430, '#b23a2a', '#ffb347', 165, 4, 16, -93) + coral(r, 500, 432, '#5a3aa8', '#d2b4ff', 175, 4, 16, -86) + coral(r, 436, 440, '#b03070', '#ff9ecb', 124, 4, 14, -90))
    s.add(mound(s, 340, 444, 32, 26, '#35c6a8', '#12788c') + mound(s, 530, 446, 28, 22, '#ffb347', '#c9562b') + shell_on_sand(410, 456))
    # 3. Deep Sea: dark rock, a glowing cave mouth, cold crystals
    s.add(boulder(s, 646, 492, 132, 90, lit='#7fb7c4', base='#245f78', dark='#0b2c48', moss=False) + boulder(s, 770, 494, 120, 72, lit='#7fb7c4', base='#245f78', dark='#0b2c48', moss=False))
    s.add('<path d="M676 494 C684 434 730 434 740 494 Z" fill="#061c3a"/><ellipse cx="708" cy="480" rx="22" ry="15" fill="#5fe0ff" opacity=".55" filter="url(#b6)"/>')
    s.add(''.join(f'<g transform="translate({x} {y}) rotate({rot})"><path d="M0 0 L{-h*.2:.0f} {-h*.7:.0f} L0 {-h} L{h*.2:.0f} {-h*.7:.0f} Z" fill="{c}"/><path d="M0 0 L0 {-h} L{h*.2:.0f} {-h*.7:.0f} Z" fill="#ffffff" opacity=".45"/></g>' for x, y, h, c, rot in ((684, 500, 36, '#8ff0ff', -16), (734, 502, 30, '#b79cff', 14), (708, 504, 22, '#8ff0ff', 2))))
    s.add(boulder(s, 30, 600, 130, 40, moss=False) + shell_on_sand(300, 588) + seastar(520, 590, 8, '#ffd27a', -70))
    s.layer('grass').add(grass(r, 120, 598, 6, 22, 46, '#1f9c7c', '#3fc79a') + grass(r, 590, 598, 6, 20, 42, '#1f9c7c', '#3fc79a'))
    s.layer('bg'); s.finish(mott=.26, streak=.14, vig=0, grain=0)
    return {n: s.svg_layer(n) for n in ('bg', 'kelp_far', 'kelp_mid', 'floor', 'grass')}

def scene_props_layers():
    """Small painted objects used by the screens: the padlock for a locked zone, and the two countable shells."""
    from chars import shell
    s = LS(5, 300, -230, 1000)
    gold = s.lin([(0, '#fff0b0', 1), (.5, '#ffcf5a', 1), (1, '#c9882a', 1)])
    s.layer('lock').add(f'<path d="M172 150 V124 a28 28 0 0 1 56 0 V150" fill="none" stroke="#e0aa42" stroke-width="13" stroke-linecap="round"/><path d="M172 150 V124 a28 28 0 0 1 56 0 V150" fill="none" stroke="#fff0b0" stroke-width="4" stroke-linecap="round" opacity=".7"/>'
                        f'<rect x="150" y="146" width="100" height="78" rx="16" fill="{gold}" stroke="#a86a14" stroke-width="3"/><circle cx="200" cy="178" r="10" fill="#3a1a0a"/><path d="M194 180 L206 180 L203 204 L197 204 Z" fill="#3a1a0a"/><ellipse cx="176" cy="160" rx="18" ry="6" fill="#ffffff" opacity=".5"/>')
    return {'lock': s.svg_layer('lock')}

from frame import scene_home_layers

SCENES2 = {
    'home': (scene_home_layers, dict(bg='bg', kelp_far='far', kelp_mid='mid', kelp_left='mid', kelp_right='mid', fg='fg', grass='grass')),
    'coral': (scene_coral_layers, dict(bg='bg', kelp_far='far', fan_left='mid', fan_right='mid', fg='fg', grass='grass')),
    'chest': (scene_chest_layers, dict(bg='bg', kelp_far='far', kelp_mid='mid', fg='fg', chest_lid='piece', chest_box='piece', lamp='prop', lamp_face='vector', grass='grass')),
    'grotto': (scene_grotto_layers, dict(bg='bg', floor='fg', walls='fg', curtain='mid', bed='piece', lights='prop', lamp='prop', lamp_face='vector')),
    'map': (scene_map_layers, dict(bg='bg', kelp_far='far', kelp_mid='mid', floor='fg', grass='grass')),
    'props': (scene_props_layers, dict(lock='prop')),
}
